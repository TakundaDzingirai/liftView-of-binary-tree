﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GoodFoodSystem
{
    public partial class OrderForm : Form
    {
        //Declare variables
        ListViewItem employeeDetails;
        public OrderForm()
        {
            InitializeComponent();
        }

        private void OrderForm_Load(object sender, EventArgs e)
        {
           
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            CataloguelistView1.Columns.Insert(0, "ID", 120, HorizontalAlignment.Left);
            CataloguelistView1.Refresh();
            CataloguelistView1.GridLines = true;
        }
    }
}
