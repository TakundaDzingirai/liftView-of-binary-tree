﻿using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GoodFoodSystem.BusinessLayer;

namespace GoodFoodSystem.DatabaseLayer
{
    public class ProductDB:DB
    {
        #region  Data members 
        private string table1 = "Catalogue";
        private string sqlLocal1 = "SELECT * FROM Catalogue";
        private string table2 = "Inventory";
        private string sqlLocal2 = "SELECT * FROM Inventory";
        private string table3 = "Product";
        private string sqlLocal3 = "SELECT * FROM Product";
        private string table4 = "Customer";
        private string sqlLocal4 = "SELECT * FROM Customer";
        private Collection<ProductItem> products;
        #endregion

        #region Property Method: Collection
        public Collection<ProductItem> AllEmployees
        {
            get
            {
                return products;
            }
        }
        #endregion

        #region Constructor
        public ProductDB() : base()
        {
            products = new Collection<ProductItem>(); //
            FillDataSet(sqlLocal1, table1);
            Add2Collection(table1);
            FillDataSet(sqlLocal2, table2);
            Add2Collection(table2);
            FillDataSet(sqlLocal3, table3);
            Add2Collection(table3);
        }
        #endregion

        #region Utility Methods
        public DataSet GetDataSet()
        {
            return dsMain;
        }
        private void Add2Collection(string table)
        {
            //Declare references to a myRow object and an Employee object
            DataRow myRow = null;
            ProductItem anProductItem;
            Catalogue catalogue;
            Inventory inventory;
            Product product;

            Role.RoleType roleValue = Role.RoleType.NoRole; //Declare roleValue and initialise
            switch (table)
            {
                case "Catalogue":
                    roleValue = Role.RoleType.Catalogue;
                    break;
                case "Product":
                    roleValue = Role.RoleType.Product;
                    break;
                case "Inventory":
                    roleValue = Role.RoleType.Inventory;
                    break;
            }
            //READ from the table  
            foreach (DataRow myRow_loopVariable in dsMain.Tables[table].Rows)
            {
                myRow = myRow_loopVariable;
                if (!(myRow.RowState == DataRowState.Deleted))
                {
                    //Instantiate a new Employee object
                    anProductItem = new ProductItem(roleValue);
                    //Obtain each pproduct attribute from the specific field in the row in the table
                    anProductItem.setProductId(Convert.ToString(myRow["ItemId"]).TrimEnd());
                    //Do the same for all other attributes
                    anProductItem.ItemName = Convert.ToString(myRow["Item Name"]).TrimEnd();
                    anProductItem.role.getRoleValue = (Role.RoleType)Convert.ToByte(myRow["Role"]);
                    //Depending on Role read more Values
                    switch (anProductItem.role.getRoleValue)
                    {
                        case Role.RoleType.Catalogue:
                            catalogue = (Catalogue)anProductItem.role;
                           
                            catalogue.Description = Convert.ToString(myRow["Description"]);
                            catalogue.Price= Convert.ToDecimal(myRow["Price"]);
                            break;
                        case Role.RoleType.Inventory:
                            inventory = (Inventory)anProductItem.role;
                            inventory.Quantity = Convert.ToInt32(myRow["Quantity"]);
                            break;
                        case Role.RoleType.Product:
                            product = (Product)anProductItem.role;
                            product.setSupplier(Convert.ToString(myRow["Supplier"]));
                            product.setDescription(Convert.ToString(myRow["Description"]));
                            product.setExpiryDate(Convert.ToString(myRow["Expiry Date"]));
                            break;
                    }
                    products.Add(anProductItem);
                }
            }
        }
        private void FillRow(DataRow aRow,ProductItem aProd,DB.DBOperation operation)
        {
           
            Catalogue catalogue;
            Inventory inventory;
            Product product;
            if (operation == DB.DBOperation.Add)
            {
                aRow["ItemId"] = aProd.getItemId();  //NOTE square brackets to indicate index of collections of fields in row.
                
            }
            aRow["Item Name"] = aProd.ItemName;

            //*** For each role add the specific data variables
            switch (aProd.role.getRoleValue)
            {
                case Role.RoleType.Catalogue:
                    catalogue = (Catalogue)aProd.role;
                    aRow["Description"] = catalogue.Description;
                    aRow["Price"] = catalogue.Price;
                    break;

                case Role.RoleType.Inventory:
                    inventory = (Inventory)aProd.role;
                    aRow["Quantity"] = inventory.Quantity;
                    break;

                case Role.RoleType.Product:
                    product = (Product)aProd.role;
                    aRow["Supplier"] = product.getSupplier();
                    aRow["Description"] = product.getDescription();
                    aRow["ExpiryDate"] = product.getExpiryDate();
                    break;
            }
        }

        private int FindRow(ProductItem aProd, string table)
        {
            int rowIndex = 0;
            DataRow myRow;
            int returnValue = -1;
            foreach (DataRow myRow_loopVariable in dsMain.Tables[table].Rows)
            {
                myRow = myRow_loopVariable;
                //Ignore rows marked as deleted in dataset
                if (!(myRow.RowState == DataRowState.Deleted))
                {
                    //In c# there is no item property (but we use the 2-dim array) it 
                    //is automatically known to the compiler when used as below
                    if (aProd.getItemId()==Convert.ToString(dsMain.Tables[table].Rows[rowIndex]["ItemId"]))
                    {
                        returnValue = rowIndex;
                    }
                }
                rowIndex += 1;
            }
            return returnValue;
        }
        #endregion

        #region Database Operations CRUD
        public void DataSetChange(ProductItem aProd, DB.DBOperation operation)
        {
            DataRow aRow = null;
            string dataTable = table1;
            switch (aProd.role.getRoleValue)
            {
                case Role.RoleType.Catalogue:
                    dataTable = table1;
                    break;
                case Role.RoleType.Inventory:
                    dataTable = table2;
                    break;
                case Role.RoleType.Product:
                    dataTable = table3;
                    break;
            }
            switch (operation)
            {
                case DB.DBOperation.Add:
                    aRow = dsMain.Tables[dataTable].NewRow();
                    FillRow(aRow, aProd, operation);
                    //Add to the dataset
                    dsMain.Tables[dataTable].Rows.Add(aRow);
                    break;
                case DB.DBOperation.Edit:
                    // to Edit
                    aRow = dsMain.Tables[dataTable].Rows[FindRow(aProd, dataTable)];
                    FillRow(aRow, aProd, operation);
                    break;
                case DB.DBOperation.Delete:
                    aRow = dsMain.Tables[dataTable].Rows[FindRow(aProd, dataTable)];
                    dsMain.Tables[dataTable].Rows.Remove(aRow);

                    break;
            }
        }
        #endregion

        #region Build Parameters, Create Commands & Update database
        private void Build_INSERT_Parameters(ProductItem aProd)
        {
            //Create Parameters to communicate with SQL INSERT...
            //add the input parameter and set its properties.             
            SqlParameter param = default(SqlParameter);
            param = new SqlParameter("@ItemId", SqlDbType.Int, 8, "ItemId");
            daMain.InsertCommand.Parameters.Add(param);//Add the parameter to the Parameters collection.

            param = new SqlParameter("@Item Name", SqlDbType.NVarChar, 100, "Item Name");
            daMain.InsertCommand.Parameters.Add(param);
            //Do the same for Description & answer -ensure that you choose the right size
            switch (aProd.role.getRoleValue)
            {
                case Role.RoleType.Catalogue:
                    
                    param = new SqlParameter("@Description", SqlDbType.NVarChar, 100, "Description");
                    daMain.InsertCommand.Parameters.Add(param);

                    param = new SqlParameter("@Price", SqlDbType.Decimal, 9, "Price");
                    daMain.InsertCommand.Parameters.Add(param);
                    break;

                case Role.RoleType.Inventory:
                    param = new SqlParameter("@Quantity", SqlDbType.Int, 8, "Quantity");
                    daMain.InsertCommand.Parameters.Add(param);
                    break;

                case Role.RoleType.Product:
                    param = new SqlParameter("@Supplier", SqlDbType.NVarChar, 100, "Supplier");
                    daMain.InsertCommand.Parameters.Add(param);

                    param = new SqlParameter("@Description", SqlDbType.NVarChar, 100, "Description");
                    daMain.InsertCommand.Parameters.Add(param);

                    param = new SqlParameter("@ExpiryDate", SqlDbType.NVarChar, 50, "ExpiryDate");
                    daMain.InsertCommand.Parameters.Add(param);
                    break;
            }
            //***https://msdn.microsoft.com/en-za/library/ms179882.aspx
        }

        private void Create_INSERT_Command(ProductItem aProd)
        {
            //Create the command that must be used to insert values into the table..
            switch (aProd.role.getRoleValue)
            {
                case Role.RoleType.Catalogue:
                    daMain.InsertCommand = new SqlCommand("INSERT into Catalogue (ItemId, Item Name, Description, Price, Role) VALUES (@ItemId, @Item Name, @Description, @Price, @Role)", cnMain);
                    break;
                case Role.RoleType.Inventory:                  
                    daMain.InsertCommand = new SqlCommand("INSERT into Inventory (ItemId, Item Name, Quantity, Role) VALUES (@ItemId, @Item Name, @Quantity, @Role)", cnMain);
                    break;
                case Role.RoleType.Product:
                    daMain.InsertCommand = new SqlCommand("INSERT into Product (ItemId, Item Name, Supplier, Description, Expiry Date, Role) VALUES (@ItemId, @Item Name @Supplier, @Description, @Expiry Date, @Role)", cnMain);
                    break;
            }
            Build_INSERT_Parameters(aProd);
        }
        private void Build_UPDATE_Parameters(ProductItem aProd)
        {
            SqlParameter param = default(SqlParameter);

            param = new SqlParameter("@Item Name", SqlDbType.NVarChar, 100, "Item Name");
            param.SourceVersion = DataRowVersion.Current;
            daMain.UpdateCommand.Parameters.Add(param);
            //Do the same for Description & answer -ensure that you choose the right size
            switch (aProd.role.getRoleValue)
            {
                case Role.RoleType.Catalogue:

                    param = new SqlParameter("@Description", SqlDbType.NVarChar, 100, "Description");
                    daMain.InsertCommand.Parameters.Add(param);

                    param = new SqlParameter("@Price", SqlDbType.Decimal, 9, "Price");
                    daMain.UpdateCommand.Parameters.Add(param);
                    break;

                case Role.RoleType.Inventory:
                    param = new SqlParameter("@Quantity", SqlDbType.Int, 8, "Quantity");
                    daMain.UpdateCommand.Parameters.Add(param);
                    break;

                case Role.RoleType.Product:
                    param = new SqlParameter("@Supplier", SqlDbType.NVarChar, 100, "Supplier");
                    daMain.UpdateCommand.Parameters.Add(param);

                    param = new SqlParameter("@Description", SqlDbType.NVarChar, 100, "Description");
                    daMain.UpdateCommand.Parameters.Add(param);

                    param = new SqlParameter("@ExpiryDate", SqlDbType.NVarChar, 50, "ExpiryDate");
                    daMain.UpdateCommand.Parameters.Add(param);
                    break;

            }
            //testing the ID of record that needs to change with the original ID of the record
            param = new SqlParameter("@Original_ID", SqlDbType.NVarChar, 15, "ItemID");
            param.SourceVersion = DataRowVersion.Original;
            daMain.UpdateCommand.Parameters.Add(param);
        }

            public bool UpdateDataSource(ProductItem aProd)
        {
            bool success = true;
            Create_INSERT_Command(aProd);
            switch (aProd.role.getRoleValue)
            {
                case Role.RoleType.Catalogue:
                    success = UpdateDataSource(sqlLocal1, table1);
                    break;
                case Role.RoleType.Inventory:
                    success = UpdateDataSource(sqlLocal2, table2);
                    break;
                case Role.RoleType.Product:
                    success = UpdateDataSource(sqlLocal3, table3);
                    break;
            }
            return success;
        }
        private void Create_UPDATE_Command(ProductItem anProd)
        {
            //Create the command that must be used to insert values into one of the three tables
            //Assumption is that the ID and EMPID cannot be changed

            switch (anProd.role.getRoleValue)
            {
                case Role.RoleType.Catalogue:
                    daMain.UpdateCommand = new SqlCommand("UPDATE Catalogue SET Item Name =@Item Name, Description =@Description, Price =@Price, Role =@Role " + "WHERE ItemID = @Original_ID", cnMain);
                    break;
                case Role.RoleType.Inventory:
                    daMain.UpdateCommand = new SqlCommand("UPDATE Inventory SET Item Name =@Item Name, Quantity =@Quantity, Role =@Role " + "WHERE ItemID = @Original_ID", cnMain);
                    break;
                case Role.RoleType.Product:
                    daMain.UpdateCommand = new SqlCommand("UPDATE Product SET Item Name =@Item Name, Supplier =@Supplier, Description =@Description, Expiry Date =@Expiry Date, Role =@Role " + "WHERE ItemID = @Original_ID", cnMain);
                    break;
            }
            Build_UPDATE_Parameters(anProd);
        }


        #endregion

    }
}
