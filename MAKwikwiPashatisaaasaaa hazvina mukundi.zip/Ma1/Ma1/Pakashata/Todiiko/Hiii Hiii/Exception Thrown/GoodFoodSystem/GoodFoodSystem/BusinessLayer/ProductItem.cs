﻿using GoodFoodSystem.DatabaseLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodFoodSystem.BusinessLayer
{
    public class ProductItem
    {
        #region Info
        /* 
          A pproduct has an pproduct number/ID and a role at the restaurant. 
          Since there are different types of product with different ROLES in a restaurant, 
          we will create a Role class. Three derived classes (headwaiter, waiter and runner) 
          that inherit the role class will be created first 
          (We can say that a waiter IS A specific role an pproduct might have in the restaurant, etc.).
          The headwaiter has only salary as a data member. The runner and the waiter have the following attributes: 
          tips, rate and noOfShifts. For now do not include the constructor for these classes. 
          Implement the classes, observing OOP principles. Include encapsulation principles.   */
        #endregion

        #region Data Members
        //encapsulation
       
        //need to define a role here - Question 3-Make sure the role data member of this class is of class type Role.
        public Role role;


        private string ItemId;

        private string itemName;

        #endregion

        #region Property methods
    

        public string ItemName { get => itemName; set => itemName = value; }
        #endregion

        #region Constructor
        /*
         * Include the constructor of the class.                                                                                                           
            The constructor should have one argument roleValue of type Role. 
            This is because upon the invocation of this class, the role of the pproduct should be determined.
            Use a switch statement to find the specific role as follows (for more on switch statements):
            If there is no role yet, then:                  role = new Role ();
            If the role is Headwaiter, then:                     role = new HeadWaiter ();

         */

        public ProductItem(Role.RoleType roleValue)

        {

            switch (roleValue)
            {
               
                case Role.RoleType.Catalogue:
                    role = new Catalogue();
                    break;
                case Role.RoleType.Inventory:
                    role = new Inventory();
                    break;
                case Role.RoleType.Product:
                    role = new Product();
                    break;
            }
        }
        public ProductItem()
        {
            this.ItemId = null;
            this.itemName = null;

        }
        #endregion


        #region Getters and Setters
        public string getItemId()
        {
            return ItemId;
        }

        public void setProductId(string id)
        {
            ItemId = id;
        }
        #endregion
    } 

      

}
