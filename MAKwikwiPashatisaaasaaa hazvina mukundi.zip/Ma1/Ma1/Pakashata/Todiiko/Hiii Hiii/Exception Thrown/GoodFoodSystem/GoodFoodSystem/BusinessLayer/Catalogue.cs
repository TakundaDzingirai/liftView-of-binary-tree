﻿using GoodFoodSystem.BusinessLayer;
using System.ComponentModel;

namespace GoodFoodSystem.DatabaseLayer
{
    internal class Catalogue:Role
    {
        #region
        private string ItemId;
        private string Name;
        private string description;
        private decimal price;
        #endregion
        public Catalogue()
        {
            ItemId1 = null;
            description = null;
            Price = 0;
        }

        public string ItemId1 { get => ItemId; set => ItemId = value; }
        public string Description { 
            get{ return description; }
            set{ description=value;}
            }

        public decimal Price { get => price; set => price = value; }
        public string Name1 { get => Name; set => Name = value; }
    }
}