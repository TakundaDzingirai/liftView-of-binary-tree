﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using GoodFoodSystem.DatabaseLayer;

namespace GoodFoodSystem.BusinessLayer
{
    public class ProductController
    {
        #region Data Members
        private  ProductDB productDB;//make reference 
        private Collection<ProductItem> product;
        #endregion

        #region Properties
        public Collection<ProductItem> AllProduct
        {
            get
            {
                return product;
            }
        }
        #endregion

        #region Constructor
        public ProductController()
        {
            //***instantiate the ProductDB object to communicate with the database
            productDB = new ProductDB();
            product = productDB.AllEmployees;
        }
        #endregion

        #region Database Communication.
        public void DataMaintenance(ProductItem aProd, DB.DBOperation operation)
        {
            //perform a given database operation to the dataset in meory; 
            
            productDB.DataSetChange(aProd,operation);//calling method to do the insert
            int index = 0;
            switch (operation)
            {
                case DB.DBOperation.Add:
                    //*** Add the employee to the Collection
                    product.Add(aProd);//
                    break;
                case DB.DBOperation.Edit:
                    index = FindIndex(aProd);
                    product[index] = aProd;  // replace employee at this index with the updated employee
                    break;
                case DB.DBOperation.Delete:
                    //  index = FindIndex(anEmp);
                    product.Remove(aProd);
                    break;
            }
        }

        //***Commit the changes to the database
        public bool FinalizeChanges(ProductItem product)
        {
            //***call the ProductDB method that will commit the changes to the database
            return productDB.UpdateDataSource(product);

        }
        #endregion

        #region Search Methods
        //This method  (function) searched through all the employess to finds onlly those with the required role
        public Collection<ProductItem> FindByRole(Collection<ProductItem> Products, Role.RoleType roleVal)
        {
            Collection<ProductItem> matches = new Collection<ProductItem>();

            foreach (ProductItem prod in Products)
            {
                if (prod.role.getRoleValue == roleVal)
                {
                    matches.Add(prod);
                }
            }
            return matches;
        }

        public ProductItem Find(string ID)
        {
            int index = 0;
            bool found = (product[index].getItemId() == ID);  //check if it is the first record
            int count = product.Count;
            while (!(found) && (index < product.Count - 1))  //if not "this" record and you are not at the end of the list 
            {
                index = index + 1;
                found = (product[index].getItemId() == ID);   // this will be TRUE if found
            }
            return product[index];  // this is the one!  
        }
        public int FindIndex(ProductItem aProd)
        {
            int counter = 0;
            bool found = false;
            found = (aProd.getItemId() == product[counter].getItemId());   //using a Boolean Expression to initialise found
            while (!(found) & counter < product.Count - 1)
            {
                counter += 1;
                found = aProd.getItemId() == product[counter].getItemId();
            }
            if (found)
            {
                return counter;
            }
            else
            {
                return -1;
            }
        }


        #endregion
    }
}
