﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GoodFoodSystem.BusinessLayer;
using GoodFoodSystem.DatabaseLayer;

namespace GoodFoodSystem.PresentationLayer
{
    public partial class EmployeeForm : Form
    {

        #region Data Members
        private ProductItem prod;
        private ProductController prodController;//
        private Role.RoleType roleValue;
        public bool employeeFormClosed = false;
        
        #endregion

        #region Constructor
        public EmployeeForm(ProductController aController)
        {
            InitializeComponent();
            prodController = aController;
        }

        #endregion

        #region Utility Methods
        private void ShowAll(bool value, Role.RoleType roleType)
        {
            idLabel.Visible = value;
            itemIDLabel.Visible = value;
            productNameLabel.Visible = value;
            descriptionLabel.Visible = value;
            supplierLabel.Visible = value;
            idTextBox.Visible = value;
            itemIDTextBox.Visible = value;
            productNameTextBox.Visible = value;
            descriptionTextBox.Visible = value;
            supplierTextBox.Visible = value;
            submitButton.Visible = value;
            cancelButton.Visible = value;
            label2.Visible = value;
            if (!(value))
            {
                productRadioButton.Checked = false;
                catalogueRadioButton.Checked = false;
                inventoryRadioButton.Checked = false;
            }
            if ((roleType == Role.RoleType.Product))
            {
                quantityLabel.Visible = value;
                quantityTextBox.Visible = value;
                priceLabel.Visible = value;
                priceTextBox.Visible = value;
                supplierLabel.Visible = value;
               
            }
            else
            {
                quantityLabel.Visible = false;
                quantityTextBox.Visible = false;
                priceLabel.Visible = false;
                priceTextBox.Visible = false;
            }
        }
        private void ClearAll()
        {
            idTextBox.Text = "";
            itemIDTextBox.Text = "";
            productNameTextBox.Text = "";
            descriptionTextBox.Text = "";
            supplierTextBox.Text = "";
            priceTextBox.Text = "";
            quantityTextBox.Text = "";
        }

        private void PopulateObject(Role.RoleType roleType)
        {
            Catalogue catalogue;
            Inventory inventory;
            Product product;

            prod = new ProductItem(roleType);
      
            prod.setProductId (itemIDTextBox.Text);
            prod.ItemName = productNameTextBox.Text;
            

            switch (prod.role.getRoleValue)
            {
                case Role.RoleType.Catalogue:
                    catalogue = (Catalogue)(prod.role);
                    catalogue.Description = descriptionTextBox.Text;
                    catalogue.Price= decimal.Parse(priceTextBox.Text);
                    break;
                case Role.RoleType.Inventory:
                    inventory = (Inventory)(prod.role);
                    inventory.Quantity = int.Parse(quantityTextBox.Text);
                    break;
                case Role.RoleType.Product:
                 product=(Product)(prod.role);
                    product.setSupplier(supplierTextBox.Text);
                    product.setDescription(descriptionTextBox.Text);
                    break;
            }
        }

        #endregion

        #region Form Events
        private void headWaitronRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            this.Text = "Add product to Catalogue";
            roleValue = Role.RoleType.Catalogue;
            ShowAll(true, roleValue);
            itemIDTextBox.Focus();
        }

        private void waitronRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            this.Text = "Add product to Inventory";
            roleValue = Role.RoleType.Inventory;
            ShowAll(true, roleValue);
            itemIDTextBox.Focus();
        }

        private void runnerRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            this.Text = "Add Product";
            roleValue = Role.RoleType.Product;
            supplierLabel.Text = "Rate";ShowAll(true, roleValue);
            itemIDTextBox.Focus();
        }

        private void submitButton_Click(object sender, EventArgs e)
        {

            PopulateObject(roleValue);
            MessageBox.Show("To be submitted to the Database!");
            prodController.DataMaintenance(prod, DB.DBOperation.Add);
            prodController.FinalizeChanges(prod);
            ClearAll();
            ShowAll(false, roleValue);
        }

        private void EmployeeForm_Load(object sender, EventArgs e)
        {
            ShowAll(false, roleValue);
           // prodController = new EmployeeController();
        }

        private void EmployeeForm_Activated(object sender, EventArgs e)
        {
            ShowAll(false, roleValue);
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {

        }

        private void extBtn_Click(object sender, EventArgs e)
        {
            employeeFormClosed = true;
        }
        #endregion
    }
}
