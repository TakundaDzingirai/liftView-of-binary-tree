﻿using GoodFoodSystem.BusinessLayer;

namespace GoodFoodSystem.DatabaseLayer
{
    internal class Inventory:Role
    {
        private string itemId;
        private int quantity;
        private string Name;

        public Inventory()
        {
            this.ItemId = null;
            this.Quantity = 0;

        }

        public string ItemId { get => itemId; set => itemId = value; }
        public int Quantity { get => quantity; set => quantity = value; }
        public string Name1 { get => Name; set => Name = value; }
    }
}