﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GoodFoodSystem.BusinessLayer;
using GoodFoodSystem.DatabaseLayer;

namespace GoodFoodSystem.PresentationLayer
{
    public partial class EmployeeListingForm : Form
    {
        #region Variables
        public bool listFormClosed;
        private Collection<ProductItem> product;
        private Role.RoleType roleValue;
        private ProductController prodController;
        private FormStates state;
        private ProductItem pproduct;
        #endregion

        #region Enumeration
        public enum FormStates
        {
            View = 0,
            Add = 1,
            Edit = 2,
            Delete = 3
        }
        #endregion

        #region Constructor
        public EmployeeListingForm(ProductController empController)
        {
            InitializeComponent();
            prodController = empController;
            this.Load += EmployeeListingForm_Load;
            this.Activated += productListingForm_Activated;
            state = FormStates.View;
        }
        #endregion

        #region Property Method       
        public Role.RoleType RoleValue
        {
            set
            {
                roleValue = value;
            }

        }
        #endregion

        #region The List View
        public void setUpProductListView()
        {
            ListViewItem productDetails;   //Declare variables
            Catalogue catalogue;
            Inventory inventory;
            Product  pr;
            //Clear current List View Control
            employeeListViews.Clear();
            //Set Up Columns of List View
            employeeListViews.Columns.Insert(0, "ItemId", 120, HorizontalAlignment.Left);
            product = null;                      //product collection will be filled by role
            switch (roleValue)                     //  Check which role to add specific headings
            {
                case Role.RoleType.NoRole:
                    // Get all the product from the EmployeeController object 
                    // (use the property) and assign to a local product collection reference
                    product = prodController.AllProduct;

                    break;
                case Role.RoleType.Catalogue:
                    //Add a FindByRole method to the EmployeeController 
                    product = prodController.FindByRole(prodController.AllProduct, Role.RoleType.Catalogue);
                    listLabel.Text = "Listing  Catalogue Products";
                    //Set Up Columns of List View
                    employeeListViews.Columns.Insert(1, "Description", 150, HorizontalAlignment.Left);
                    employeeListViews.Columns.Insert(2, "Price", 150, HorizontalAlignment.Left);
                    break;
                //do for the others
                case Role.RoleType.Inventory:
                    //Add a FindByRole method to the EmployeeController 
                    product = prodController.FindByRole(prodController.AllProduct, Role.RoleType.Inventory);
                    listLabel.Text = "Listing of all inventory Products";
                    //Set Up Columns of List View
                    employeeListViews.Columns.Insert(1, "Quantity", 100, HorizontalAlignment.Center);

                    break;
                case Role.RoleType.Product:
                    //Add a FindByRole method to the EmployeeController 
                    product = prodController.FindByRole(prodController.AllProduct, Role.RoleType.Product);
                    listLabel.Text = "Listing of all Products";
                    //Set Up Columns of List View
                    employeeListViews.Columns.Insert(1, "Supplier", 120, HorizontalAlignment.Left);
                    employeeListViews.Columns.Insert(2, "Description", 150, HorizontalAlignment.Left);
                    employeeListViews.Columns.Insert(3, "Expiry Date", 100, HorizontalAlignment.Left);
                    break;
            }
            //Add prod details to each ListView item 
            foreach (ProductItem prod in product)
            {
                productDetails = new ListViewItem();
                productDetails.Text = prod.getItemId().ToString();
                productDetails.SubItems.Add(prod.ItemName);


                switch (prod.role.getRoleValue)
                {
                    case Role.RoleType.Catalogue:
                        catalogue = (Catalogue)prod.role;
                        productDetails.SubItems.Add(catalogue.getDescription.ToString());
                        break;
                    case Role.RoleType.Inventory:
                        inventory = (Inventory)prod.role;
                        productDetails.SubItems.Add(inventory.Quantity.ToString());
                        productDetails.SubItems.Add(inventory.Quantity.ToString());
                        break;
                    case Role.RoleType.Product:
                        pr = (Product)prod.role;
                        productDetails.SubItems.Add(pr.getSupplier());
                        productDetails.SubItems.Add(pr.getDescription());
                        productDetails.SubItems.Add(pr.getExpiryDate());
                        break;
                }
                employeeListViews.Items.Add(productDetails);
            }
            employeeListViews.Refresh();
            employeeListViews.GridLines = true;
        }
        #endregion

        #region Form Events
        private void EmployeeListingForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            listFormClosed = true;
        }

        private void EmployeeListingForm_Load(object sender, EventArgs e)
        {
            employeeListViews.View = View.Details;
        }

        private void productListingForm_Activated(object sender, EventArgs e)
        {
            employeeListViews.View = View.Details;

        }

        #endregion

        #region Utility Methods
        private void ShowAll(bool value, Role.RoleType roleType)
        {
            idLabel.Visible = value;
            itemNameLabel.Visible = value;
            supplierLabel.Visible = value;
            descriptionLabel.Visible = value;
            ExpiryDateLabel.Visible = value;
            idTextBox.Visible = value;
            ItemNameTextBox.Visible = value;
            SupplierTextBox.Visible = value;
            DescriptionTextBox.Visible = value;
            expiryDateTextBox.Visible = value;
            QuantitytextBox1.Visible = value;
            lblquantity.Visible = value;
            //If the form state is View, the Submit button and the Edit button should not be visible
            if (state == FormStates.Delete)
            {
                cancelButton.Visible = !value;
                submitButton.Visible = !value;
            }
            else
            {
                cancelButton.Visible = value;
                submitButton.Visible = value;
            }
            deleteButton.Visible = value;
            editButton.Visible = value;

            if ((roleType == Role.RoleType.Product))
            {
                supplierLabel.Visible = value;
                SupplierTextBox.Visible = value;
                DescriptionTextBox.Visible = value;
                descriptionLabel.Visible = value;
                expiryDateTextBox.Visible = value;
                ExpiryDateLabel.Visible = value;
            }
            else if ((roleType == Role.RoleType.Inventory))
            {
                supplierLabel.Visible = !value;
                SupplierTextBox.Visible = !value;
                DescriptionTextBox.Visible = !value;
                descriptionLabel.Visible = !value;
                expiryDateTextBox.Visible = !value;
                ExpiryDateLabel.Visible = !value;
            }
            else if ((roleType == Role.RoleType.Catalogue))
            {
                supplierLabel.Visible = !value;
                SupplierTextBox.Visible = !value;
                DescriptionTextBox.Visible = value;
                descriptionLabel.Visible = value;
                expiryDateTextBox.Visible = !value;
                ExpiryDateLabel.Visible = !value;
                pricetextBox1.Visible = value;
                pricelbl.Visible = value;
                QuantitytextBox1.Visible = !value;
                lblquantity.Visible = !value;



            }

        }
        private void EnableEntries(bool value)
        {
            if ((state == FormStates.Edit) && value)
            {
                idTextBox.Enabled = !value;
                ItemNameTextBox.Enabled = !value;
            }
            else
            {
                idTextBox.Enabled = value;
                ItemNameTextBox.Enabled = value;
            }
            SupplierTextBox.Enabled = value;
            DescriptionTextBox.Enabled = value;
            expiryDateTextBox.Enabled = value;

            if (state == FormStates.Delete)
            {
                cancelButton.Visible = !value;
                submitButton.Visible = !value;
            }
            else
            {
                cancelButton.Visible = value;
                submitButton.Visible = value;
            }
        }
        private void ClearAll()
        {
            idTextBox.Text = "";
            ItemNameTextBox.Text = "";
            SupplierTextBox.Text = "";
            DescriptionTextBox.Text = "";
            expiryDateTextBox.Text = "";

        }

        private void PopulateTextBoxes(ProductItem prod)
        {

            Inventory inventory;
            Catalogue catalogue;
            Product product;
            idTextBox.Text = prod.getItemId();
            SupplierTextBox.Text = prod.ItemName;
         

            switch (prod.role.getRoleValue)
            {
                case Role.RoleType.Product:
                    product = (Product)(prod.role);
                    SupplierTextBox.Text = product.getSupplier();
                    DescriptionTextBox.Text = product.getDescription();
                    expiryDateTextBox.Text = Convert.ToString(product.getExpiryDate());
                    break;
                case Role.RoleType.Inventory:
                    inventory = (Inventory)(prod.role);
                    QuantitytextBox1.Text = Convert.ToString(inventory.Quantity);

                    break;
                case Role.RoleType.Catalogue:
                    catalogue = (Catalogue)(prod.role);
                    DescriptionTextBox.Text = catalogue.getDescription;
                    pricetextBox1.Text = Convert.ToString(catalogue.Price);

                    break;
            }
        }

        #endregion

        private void employeeListViews_SelectedIndexChanged(object sender, EventArgs e)
        {
            ShowAll(true, roleValue);
            state = FormStates.View;
            EnableEntries(false);
            if (employeeListViews.SelectedItems.Count > 0)   // if you selected an item 
            {
                pproduct = prodController.Find(employeeListViews.SelectedItems[0].Text);  //selected prod becoms current prod
                                                                                          //prod = prodController.Find(Convert.ToString(employeeListViews.SelectedItems[0]));  //selected prod becomes current prod
                PopulateTextBoxes(pproduct);

            }
        }

        private void editButton_Click(object sender, EventArgs e)
        {

        }

        private void idTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void PopulateObject(Role.RoleType roleType)
        {

            Product product;
            Catalogue catalogue;
            Inventory inventory;
            Role.RoleType ro = roleType;

            pproduct = new ProductItem(roleType);
            pproduct.setProductId(idTextBox.Text);
            pproduct.ItemName = ItemNameTextBox.Text;

            switch (pproduct.role.getRoleValue)
            {
                case Role.RoleType.Catalogue:
                    catalogue = (Catalogue)(pproduct.role);
                    catalogue.Price = decimal.Parse(pricetextBox1.Text);
                    catalogue.Description = DescriptionTextBox.Text;
                    break;

                case Role.RoleType.Inventory:
                    inventory = (Inventory)(pproduct.role);
                    inventory.Quantity = int.Parse(QuantitytextBox1.Text);
                    break;

                case Role.RoleType.Product:
                    product = (Product)(pproduct.role);
                    product.setSupplier(SupplierTextBox.Text);
                    product.setDescription(SupplierTextBox.Text);
                    product.setExpiryDate(SupplierTextBox.Text);
                    break;
            }
        }

        private void submitButton_Click(object sender, EventArgs e)
        {
            PopulateObject(roleValue);
            if (state == FormStates.Edit)
            {
                prodController.DataMaintenance(pproduct, DB.DBOperation.Edit);

            }
            else//delete code
            {
                // employeeController.DataMaintenance(employee, DB.DBOperation.Delete);
            }
            prodController.FinalizeChanges(pproduct);
            ClearAll();
            state = FormStates.View;
            ShowAll(false, roleValue);
            setUpProductListView();   //refresh List View
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {

            // Using the delete button on click code

            state = FormStates.Delete;
            editButton.Visible = false;
            // submitButton.Visible = true;
            EnableEntries(true);
            prodController.DataMaintenance(pproduct, DB.DBOperation.Delete);
            prodController.FinalizeChanges(pproduct);
            state = FormStates.View;
            ShowAll(false, roleValue);
            setUpProductListView();
        }
    }
 

    }

