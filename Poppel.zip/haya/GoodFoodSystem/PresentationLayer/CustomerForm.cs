﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace GoodFoodSystem.PresentationLayer
{
    public partial class CustomerForm : Form
    {
        //private string strConn = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\Takunda\\Downloads\\haya\\GoodFoodSystem\\goodfoodDatabase.mdf;Integrated Security=True";
        protected SqlConnection cnMain;
        protected SqlCommand cmd;
       OrderForm orderForm;
      
        public CustomerForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {


            //Open a connection & create a new dataset object
            cnMain = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\Takunda\\Downloads\\haya\\GoodFoodSystem\\GoodFoodDatabase.mdf;Integrated Security=True");// A SqlConnection is an object, just like any other C# object


            try
            {
                cnMain.Open();
                // SqlCommand cmd = new SqlCommand("sp_insert", conn);
                string query = "insert into [Customer] ([ID], [Name], [Phone], [Email], [Address], [CreditStatus], [BlackListStatus]) values (@id,@nm,@phn,@em,@ad,@cr,@bl)";

                //cmd.CommandType = CommandType.StoredProcedure;

                // Create the connection (and be sure to dispose it at the end)


                // Open the connection to the database. 
                // This is the first critical step in the process.
                // If we cannot reach the db then we have connectivity problems


                // Prepare the command to be executed on the db
                cmd = new SqlCommand(query, cnMain);

                // Create and set the parameters 
                // (@id,@nm,@phn,@em,@ad,@cr,@bl)";
                cmd.Parameters.Add("@id", SqlDbType.NVarChar).Value = textBox1.Text;
                cmd.Parameters.Add("@nm", SqlDbType.NVarChar).Value = textBox2.Text;
                cmd.Parameters.Add("@phn", SqlDbType.NVarChar).Value = textBox3.Text;
                cmd.Parameters.Add("@em", SqlDbType.NVarChar).Value = textBox4.Text;
                cmd.Parameters.Add("@ad", SqlDbType.NVarChar).Value = textBox5.Text;
                cmd.Parameters.Add("@cr", SqlDbType.NVarChar).Value = textBox7.Text;
                cmd.Parameters.Add("@bl", SqlDbType.NVarChar).Value = textBox8.Text;

                



                // Let's ask the db to execute the query
                int rowsAdded = cmd.ExecuteNonQuery();
                if (rowsAdded > 0)
                    MessageBox.Show("Customer added!!");
                else
                    // Well this should never really happen
                    MessageBox.Show("No row inserted");


            }
            catch (Exception ex)
            {
                // We should log the error somewhere, 
                // for this example let's just show a message
                MessageBox.Show("ERROR:" + ex.Message);
            }
            cnMain.Close();
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox7.Clear();
            textBox8.Clear();


           
            DialogResult dialogResult = MessageBox.Show("Do you want to Order for this Customer","" ,MessageBoxButtons.YesNo);
            


            if(dialogResult==DialogResult.Yes)
            {
                
                
                orderForm = new OrderForm();
                orderForm.Show();
                this.Hide();

            }









        }
    }
}
