﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GoodFoodSystem.BusinessLayer;
using GoodFoodSystem.DatabaseLayer;

namespace GoodFoodSystem.PresentationLayer
{
    public partial class EmployeeForm : Form
    {
       
        #region Data Members
        private ProductList employee;
        private EmployeeController employeeController;//
        private Role.RoleType roleValue;
        public bool employeeFormClosed = false;

        #endregion

        #region Property Method

        public Role.RoleType RoleValue
        {

            set
            {

                roleValue = value;
            }

        }

        #endregion

        #region Constructor
        public EmployeeForm(EmployeeController aController)
        {
            InitializeComponent();
            employeeController = aController;
        }

        #endregion

        #region Utility Methods
        private void ShowAll(bool value, Role.RoleType roleType)
        {
            idLabel.Visible = value;
            empIDLabel.Visible = value;
            descriptionLabel.Visible = value;
            supplierlbl.Visible = value;
            quantityLabel.Visible = value;
            idTextBox.Visible = value;
            productNameTextBox.Visible = value;
            descriptionTextBox.Visible = value;
            supplierTextBox.Visible = value;
            quantityTextBox.Visible = value;
            submitButton.Visible = value;
            cancelButton.Visible = value;
            label2.Visible = value;
            ExpiryTextBox.Visible = value;
            expiryLabel.Visible = value;
            quantityLabel.Visible= value;
          

            if (!(value))
            {
                headWaitronRadioButton.Checked = false;
                waitronRadioButton.Checked = false;
                runnerRadioButton.Checked = false;
            }
            if ((roleType == Role.RoleType.Waiter) || (roleType == Role.RoleType.Runner) && value)
            {
                expiryLabel.Visible = value;
                ExpiryTextBox.Visible = value;
                hoursLabel.Visible = value;
                hoursTextBox.Visible = value;
            }
            else
            {
                //expiryLabel.Visible = false;
                //ExpiryTextBox.Visible = false;
                hoursLabel.Visible = false;
                hoursTextBox.Visible = false;
            }
        }
        private void ClearAll()
        {
            idTextBox.Text = "";
            productNameTextBox.Text = "";
            descriptionTextBox.Text = "";
            supplierTextBox.Text = "";
            quantityTextBox.Text = "";
            hoursTextBox.Text = "";
            ExpiryTextBox.Text = "";

        }
        private void PopulateObject(Role.RoleType roleType)
        {
            Product headW;
            Waiter waiter;
            Runner runner;
            employee = new ProductList(roleType);
            employee.ID = idTextBox.Text;
            employee.EmployeeID = productNameTextBox.Text;
            employee.Name = descriptionTextBox.Text;
            employee.Telephone = supplierTextBox.Text;

            switch (employee.role.getRoleValue)
            {
                case Role.RoleType.Headwaiter:
                    headW = (Product)(employee.role);
                    headW.SalaryAmount = int.Parse(quantityTextBox.Text);
                    headW.ExpiryDate = ExpiryTextBox.Text;
                    break;
                case Role.RoleType.Waiter:
                    waiter = (Waiter)(employee.role);
                    waiter.getRate = decimal.Parse(quantityTextBox.Text);
                    waiter.getShifts = int.Parse(hoursTextBox.Text);
                    waiter.getTips = decimal.Parse(ExpiryTextBox.Text);
                    break;
                case Role.RoleType.Runner:
                    runner = (Runner)(employee.role);
                    runner.getRate = decimal.Parse(quantityTextBox.Text);
                    runner.getShifts = int.Parse(hoursTextBox.Text);
                    break;
            }
        }

        #endregion

        #region Form Events
        private void headWaitronRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            this.Text = "Add Product";
            roleValue = Role.RoleType.Headwaiter;
          
            ShowAll(true, roleValue);
            idTextBox.Focus();
        }

        private void waitronRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            this.Text = "Add Waiter";
            roleValue = Role.RoleType.Waiter;
            quantityLabel.Text = "Rate";
            ShowAll(true, roleValue);
            idTextBox.Focus();
        }

        private void runnerRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            this.Text = "Add Runner";
            roleValue = Role.RoleType.Runner;
            quantityLabel.Text = "Rate";
            ShowAll(true, roleValue);
            idTextBox.Focus();
        }

        private void submitButton_Click(object sender, EventArgs e)
        {

            PopulateObject(roleValue);
            MessageBox.Show("To be submitted to the Database!");
            employeeController.DataMaintenance(employee, DB.DBOperation.Add);
            employeeController.FinalizeChanges(employee);
            ClearAll();
            ShowAll(false, roleValue);
        }

        private void EmployeeForm_Load(object sender, EventArgs e)
        {
            ShowAll(false, roleValue);
           
        }

        private void EmployeeForm_Activated(object sender, EventArgs e)
        {
            ShowAll(false, roleValue);
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {

        }

        private void extBtn_Click(object sender, EventArgs e)
        {
            employeeFormClosed = true;
        }
        #endregion
    }
}
