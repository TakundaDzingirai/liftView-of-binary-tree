﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GoodFoodSystem.BusinessLayer;
using GoodFoodSystem.DatabaseLayer;

namespace GoodFoodSystem.PresentationLayer
{
    public partial class EmployeeListingForm : Form
    {
        #region Variables
        public bool listFormClosed;
        private Collection<ProductList> employees;
        private Role.RoleType roleValue;
        private EmployeeController employeeController;
        private FormStates state;
        private ProductList employee;
        #endregion

        #region Enumeration
        public enum FormStates
        {
            View = 0,
            Add = 1,
            Edit = 2,
            Delete = 3
        }
        #endregion

        #region Constructor
        public EmployeeListingForm(EmployeeController empController)
        {
            InitializeComponent();
            employeeController = empController;
            this.Load += EmployeeListingForm_Load;
            this.Activated += EmployeeListingForm_Activated;
            this.FormClosed += EmployeeListingForm_FormClosed;
            state = FormStates.View;
        }
        #endregion

        #region Property Method       
        public Role.RoleType RoleValue
        {
            set
            {
                roleValue = value;
            }

        }
        #endregion

        #region The List View
        public void setUpEmployeeListView()
        {
            ListViewItem employeeDetails;   //Declare variables
            Product headW;
            Waiter waiter;
            Runner runner;
            //Clear current List View Control
            employeeListViews.Clear();
            //Set Up Columns of List View
            employeeListViews.Columns.Insert(0, "Product ID", 120, HorizontalAlignment.Left);
            employeeListViews.Columns.Insert(1, "Product Name", 120, HorizontalAlignment.Left);
            employeeListViews.Columns.Insert(2, "Description", 150, HorizontalAlignment.Left);
            employeeListViews.Columns.Insert(3, "Supplier", 100, HorizontalAlignment.Left);            
            employees = null;                      //employees collection will be filled by role
            switch (roleValue)                     //  Check which role to add specific headings
            {
                case Role.RoleType.NoRole:
                    // Get all the employees from the EmployeeController object 
                    // (use the property) and assign to a local employees collection reference
                    employees = employeeController.AllEmployees;
                    listLabel.Text = "Listing of all employees";
                    employeeListViews.Columns.Insert(4, "Payment", 100, HorizontalAlignment.Center);
                    break;
                case Role.RoleType.Headwaiter:
                    //Add a FindByRole method to the EmployeeController 
                    employees = employeeController.FindByRole(employeeController.AllEmployees, Role.RoleType.Headwaiter);
                    listLabel.Text = "Listing of all Products";
                    //Set Up Columns of List View
                    employeeListViews.Columns.Insert(4, "Quantity", 100, HorizontalAlignment.Center);
                    employeeListViews.Columns.Insert(5, "ExpiryDate", 100, HorizontalAlignment.Center);
                    break;
                //do for the others
                case Role.RoleType.Waiter:
                    //Add a FindByRole method to the EmployeeController 
                    employees = employeeController.FindByRole(employeeController.AllEmployees, Role.RoleType.Waiter);
                    listLabel.Text = "Listing of all Waiters";
                    //Set Up Columns of List View
                    employeeListViews.Columns.Insert(4, "Rate", 100, HorizontalAlignment.Center);
                    employeeListViews.Columns.Insert(5, "Number of Shifts", 100, HorizontalAlignment.Center);
                    employeeListViews.Columns.Insert(6, "Tips", 100, HorizontalAlignment.Center);
                    break;
                case Role.RoleType.Runner:
                    //Add a FindByRole method to the EmployeeController 
                    employees = employeeController.FindByRole(employeeController.AllEmployees, Role.RoleType.Runner);
                    listLabel.Text = "Listing of all Runners";
                    //Set Up Columns of List View
                    employeeListViews.Columns.Insert(4, "Rate", 100, HorizontalAlignment.Center);
                    employeeListViews.Columns.Insert(5, "Number of Shifts", 100, HorizontalAlignment.Center);
                    employeeListViews.Columns.Insert(6, "Tips", 100, HorizontalAlignment.Center);
                    break;
            }
            //Add employee details to each ListView item 
            foreach (ProductList employee in employees)
            {
                employeeDetails = new ListViewItem();
                employeeDetails.Text = employee.ID.ToString();
                employeeDetails.SubItems.Add(employee.EmployeeID);
                employeeDetails.SubItems.Add(employee.Name);
                employeeDetails.SubItems.Add(employee.Telephone);

                switch (employee.role.getRoleValue)
                {
                    case Role.RoleType.Headwaiter:
                        headW = (Product)employee.role;
                        employeeDetails.SubItems.Add(headW.SalaryAmount.ToString());
                        employeeDetails.SubItems.Add(headW.ExpiryDate);
                        break;
                    case Role.RoleType.Waiter:
                        waiter = (Waiter)employee.role;
                        employeeDetails.SubItems.Add(waiter.getRate.ToString());
                        employeeDetails.SubItems.Add(waiter.getShifts.ToString());
                        employeeDetails.SubItems.Add(waiter.getTips.ToString());
                        break;
                    case Role.RoleType.Runner:
                        runner = (Runner)employee.role;
                        employeeDetails.SubItems.Add(runner.getRate.ToString());
                        employeeDetails.SubItems.Add(runner.getShifts.ToString());
                        employeeDetails.SubItems.Add(runner.getTips.ToString());
                        break;
                }
                employeeListViews.Items.Add(employeeDetails);
            }
            employeeListViews.Refresh();
            employeeListViews.GridLines = true;
        }
        #endregion

        #region Form Events
        private void EmployeeListingForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            listFormClosed = true;
        }

        private void EmployeeListingForm_Load(object sender, EventArgs e)
        {
            employeeListViews.View = View.Details;
        }

        private void EmployeeListingForm_Activated(object sender, EventArgs e)
        {
            employeeListViews.View = View.Details;
            setUpEmployeeListView();
            ShowAll(false, roleValue);

        }

        #endregion

        #region Utility Methods
        private void ShowAll(bool value, Role.RoleType roleType)
        {
            idLabel.Visible = value;
            productNameLabel.Visible = value;
            DescriptionLbl.Visible = value;
            supplierLabel.Visible = value;
            quantityLabel.Visible = value;
            tipsLabel.Visible = value;
            idTextBox.Visible = value;
            ProductNameTextBox.Visible = value;
            nameTextBox.Visible = value;
            supplierTextBox.Visible = value;
            quantityTextBox.Visible = value;
            tipsTextBox.Visible = value;
            expiryDateTextBox.Visible = value;
            expiryDateLabel.Visible = value;
            //If the form state is View, the Submit button and the Edit button should not be visible
            if (state == FormStates.Delete)
            {
                cancelButton.Visible = !value;
                submitButton.Visible = !value;
            }
            else
            {
                cancelButton.Visible = value;
                submitButton.Visible = value;
            }
            deleteButton.Visible = value;
            editButton.Visible = value;

            if ((roleType == Role.RoleType.Waiter) || (roleType == Role.RoleType.Runner) && value)
            {
                expiryDateLabel.Visible = value;
                expiryDateTextBox.Visible = value;
                tipsLabel.Visible = value;
                tipsTextBox.Visible = value;
            }
            else
            {
                //expiryDateLabel.Visible = false;
                //expiryDateTextBox.Visible = false;
                tipsLabel.Visible = false;
                tipsTextBox.Visible = false;
            }

        }
        private void EnableEntries(bool value)
        {
            if ((state == FormStates.Edit) && value)
            {
                idTextBox.Enabled = !value;
                ProductNameTextBox.Enabled = !value;
            }
            else
            {
                idTextBox.Enabled = value;
                ProductNameTextBox.Enabled = value;
            }
            nameTextBox.Enabled = value;
            supplierTextBox.Enabled = value;
            quantityTextBox.Enabled = value;
            expiryDateTextBox.Enabled = value;
            tipsTextBox.Enabled = value;
            if (state == FormStates.Delete)
            {
                cancelButton.Visible = !value;
                submitButton.Visible = !value;
            }
            else
            {
                cancelButton.Visible = value;
                submitButton.Visible = value;
            }
        }
        private void ClearAll()
        {
            idTextBox.Text = "";
            ProductNameTextBox.Text = "";
            nameTextBox.Text = "";
            supplierTextBox.Text = "";
            quantityTextBox.Text = "";
            expiryDateTextBox.Text = "";
            tipsTextBox.Text = "";
        }
        private void PopulateTextBoxes(ProductList emp)
        {
            Product headW;
            Waiter waiter;
            Runner runner;
            idTextBox.Text = emp.ID;          
            ProductNameTextBox.Text = emp.EmployeeID;
            nameTextBox.Text = emp.Name;
            supplierTextBox.Text = emp.Telephone;

            switch (emp.role.getRoleValue)
            {
                case Role.RoleType.Headwaiter:
                    headW = (Product)(emp.role);
                    quantityTextBox.Text = Convert.ToString(headW.SalaryAmount);
                    expiryDateTextBox.Text = headW.ExpiryDate;
                    break;
                case Role.RoleType.Waiter:
                    waiter = (Waiter)(emp.role);
                    quantityTextBox.Text = Convert.ToString(waiter.getRate);
                    expiryDateTextBox.Text = Convert.ToString(waiter.getShifts);
                    tipsTextBox.Text = Convert.ToString(waiter.getTips);
                    break;
                case Role.RoleType.Runner:
                    runner = (Runner)(emp.role);
                    quantityTextBox.Text = Convert.ToString(runner.getRate);
                    expiryDateTextBox.Text = Convert.ToString(runner.getShifts);
                    tipsTextBox.Text = Convert.ToString(runner.getTips);
                    break;
            }
        }
        private void PopulateObject(Role.RoleType roleType)
        {
            Product headW;
            Waiter waiter;
            Runner runner;
            employee = new ProductList(roleType);
            employee.ID = idTextBox.Text;
            employee.EmployeeID = ProductNameTextBox.Text;
            employee.Name = nameTextBox.Text;
            employee.Telephone = supplierTextBox.Text;

            switch (employee.role.getRoleValue)
            {
                case Role.RoleType.Headwaiter:
                    headW = (Product)(employee.role);
                    headW.SalaryAmount = int.Parse(quantityTextBox.Text);
                    headW.ExpiryDate = expiryDateTextBox.Text;
                 
                    break;
                case Role.RoleType.Waiter:                    
                    waiter = (Waiter)(employee.role);
                    waiter.getRate = decimal.Parse(quantityTextBox.Text);
                    waiter.getShifts = int.Parse(expiryDateTextBox.Text);
                    waiter.getTips = decimal.Parse(tipsTextBox.Text);                    
                    break;
                case Role.RoleType.Runner:                    
                    runner = (Runner)(employee.role);
                    runner.getRate = decimal.Parse(quantityTextBox.Text);
                    runner.getShifts = int.Parse(expiryDateTextBox.Text);
                    runner.getTips = decimal.Parse(tipsTextBox.Text);
                    break;
            }
        }

        #endregion

        private void employeeListViews_SelectedIndexChanged(object sender, EventArgs e)
        {
            ShowAll(true, roleValue) ;
            state = FormStates.View;
            EnableEntries(false);
            if (employeeListViews.SelectedItems.Count > 0)   // if you selected an item 
            {
              employee = employeeController.Find(employeeListViews.SelectedItems[0].Text);  //selected employee becoms current employee
             //employee = employeeController.Find(Convert.ToString(employeeListViews.SelectedItems[0]));  //selected employee becomes current employee
                PopulateTextBoxes(employee);
                
                }
        }

        private void editButton_Click(object sender, EventArgs e)
        {
            //set the form state to Edit
            state = FormStates.Edit;
            deleteButton.Visible = false;
            EnableEntries(true);//call the EnableEntities method

        }

        private void submitButton_Click(object sender, EventArgs e)
        {
            PopulateObject(roleValue);
            if (state == FormStates.Edit)
            {
                employeeController.DataMaintenance(employee, DB.DBOperation.Edit);

            }
            else//delete code
            {
               // employeeController.DataMaintenance(employee, DB.DBOperation.Delete);
            }
            employeeController.FinalizeChanges(employee);
            ClearAll();
            state = FormStates.View;
            ShowAll(false, roleValue);
            setUpEmployeeListView();   //refresh List View
        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            state = FormStates.Delete;
            editButton.Visible = false;
           // submitButton.Visible = true;
            EnableEntries(true);
            employeeController.DataMaintenance(employee, DB.DBOperation.Delete);
            employeeController.FinalizeChanges(employee);
            state = FormStates.View;
            ShowAll(false, roleValue);
            setUpEmployeeListView();
           
        }
    }
}
