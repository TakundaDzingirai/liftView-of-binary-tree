﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodFoodSystem.BusinessLayer
{
    internal class Order
    {

        private string orderID;
        private string orderDate;
        private decimal totalAmmount;




        public Order()
        {
            orderDate = null;
            totalAmmount = 0;
            orderID=null;
        }

        public string OrderID { get => orderID; set => orderID = value; }
        public string OrderDate { get => orderDate; set => orderDate = value; }
        public decimal TotalAmmount { get => totalAmmount; set => totalAmmount = value; }
    }
}
