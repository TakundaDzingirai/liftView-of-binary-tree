﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GoodFoodSystem.BusinessLayer;
using GoodFoodSystem.DatabaseLayer;

namespace GoodFoodSystem.PresentationLayer
{
    public partial class EmployeeListingForm : Form
    {
        #region Variables
        public bool listFormClosed;
        private Collection<Product> product;
        private Role.RoleType roleValue;
        private ProductController prodController;
        private FormStates state;
        private Product employee;
        #endregion

        #region Enumeration
        public enum FormStates
        {
            View = 0,
            Add = 1,
            Edit = 2,
            Delete = 3
        }
        #endregion

        #region Constructor
        public EmployeeListingForm(ProductController empController)
        {
            InitializeComponent();
            prodController = empController;
            this.Load += EmployeeListingForm_Load;
            this.Activated += productListingForm_Activated;
            state = FormStates.View;
        }
        #endregion

        #region Property Method       
        public Role.RoleType RoleValue
        {
            set
            {
                roleValue = value;
            }

        }
        #endregion

        #region The List View
        public void setUpProductListView()
        {
            ListViewItem productDetails;   //Declare variables
            Catalogue catalogue;
            Inventory inventory;
            Runner runner;
            //Clear current List View Control
            employeeListViews.Clear();
            //Set Up Columns of List View
            employeeListViews.Columns.Insert(0, "ItemId", 120, HorizontalAlignment.Left);
            product = null;                      //product collection will be filled by role
            switch (roleValue)                     //  Check which role to add specific headings
            {
                case Role.RoleType.NoRole:
                    // Get all the product from the EmployeeController object 
                    // (use the property) and assign to a local product collection reference
                    product = prodController.AllProduct;
                    
                    break;
                case Role.RoleType.Catalogue:
                    //Add a FindByRole method to the EmployeeController 
                    product = prodController.FindByRole(prodController.AllProduct, Role.RoleType.Catalogue);
                    listLabel.Text = "Listing  Catalogue Products";
                    //Set Up Columns of List View
                    employeeListViews.Columns.Insert(1, "Description", 150, HorizontalAlignment.Left);
                    employeeListViews.Columns.Insert(2, "Price", 150, HorizontalAlignment.Left);
                    break;
                //do for the others
                case Role.RoleType.Inventory:
                    //Add a FindByRole method to the EmployeeController 
                    product = prodController.FindByRole(prodController.AllProduct, Role.RoleType.Inventory);
                    listLabel.Text = "Listing of all inventory Products";
                    //Set Up Columns of List View
                    employeeListViews.Columns.Insert(1, "Quantity", 100, HorizontalAlignment.Center);
                    
                    break;
                case Role.RoleType.Product:
                    //Add a FindByRole method to the EmployeeController 
                    product = prodController.FindByRole(prodController.AllProduct, Role.RoleType.Product);
                    listLabel.Text = "Listing of all Products";
                    //Set Up Columns of List View
                    employeeListViews.Columns.Insert(1, "Supplier", 120, HorizontalAlignment.Left);
                    employeeListViews.Columns.Insert(2, "Description", 150, HorizontalAlignment.Left);
                    employeeListViews.Columns.Insert(3, "Expiry Date", 100, HorizontalAlignment.Left);
                    break;
            }
            //Add prod details to each ListView item 
            foreach (Product prod in product)
            {
                productDetails = new ListViewItem();
                productDetails.Text = prod.getItemId().ToString();
                productDetails.SubItems.Add(prod.ItemName);
                

                switch (prod.role.getRoleValue)
                {
                    case Role.RoleType.Catalogue:
                        catalogue = (Catalogue)prod.role;
                        productDetails.SubItems.Add(catalogue.getDescription.ToString());
                        break;
                    case Role.RoleType.Inventory:
                        inventory = (Inventory)prod.role;
                        productDetails.SubItems.Add(inventory.Quantity.ToString());
                        productDetails.SubItems.Add(inventory.Quantity.ToString());
                        break;
                    case Role.RoleType.Product:
                        runner = (Runner)prod.role;
                        productDetails.SubItems.Add(prod.getSupplier());
                        productDetails.SubItems.Add(prod.getDescription());
                        productDetails.SubItems.Add(prod.getExpiryDate());
                        break;
                }
                employeeListViews.Items.Add(productDetails);
            }
            employeeListViews.Refresh();
            employeeListViews.GridLines = true;
        }
        #endregion

        #region Form Events
        private void EmployeeListingForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            listFormClosed = true;
        }

        private void EmployeeListingForm_Load(object sender, EventArgs e)
        {
            employeeListViews.View = View.Details;
        }

        private void productListingForm_Activated(object sender, EventArgs e)
        {
            employeeListViews.View = View.Details;

        }

        #endregion

        #region Utility Methods
        private void ShowAll(bool value, Role.RoleType roleType)
        {
            idLabel.Visible = value;
            itemNameLabel.Visible = value;
            supplierLabel.Visible = value;
            descriptionLabel.Visible = value;
            ExpiryDateLabel.Visible = value;
            idTextBox.Visible = value;
            ItemNameTextBox.Visible = value;
            SupplierTextBox.Visible = value;
            DescriptionTextBox.Visible = value;
            expiryDateTextBox.Visible = value;
            //If the form state is View, the Submit button and the Edit button should not be visible
            if (state == FormStates.Delete)
            {
                cancelButton.Visible = !value;
                submitButton.Visible = !value;
            }
            else
            {
                cancelButton.Visible = value;
                submitButton.Visible = value;
            }
            deleteButton.Visible = value;
            editButton.Visible = value;

            if ((roleType == Role.RoleType.Product))
            {
                supplierLabel.Visible = value;
                SupplierTextBox.Visible= value;
                DescriptionTextBox.Visible= value;
                descriptionLabel.Visible = value;
                expiryDateTextBox.Visible= value;
                ExpiryDateLabel.Visible= value;
            }
            else if((roleType == Role.RoleType.Inventory))
            {
                supplierLabel.Visible = !value;
                SupplierTextBox.Visible = !value;
                DescriptionTextBox.Visible =! value;
                descriptionLabel.Visible =! value;
                expiryDateTextBox.Visible = !value;
                ExpiryDateLabel.Visible = !value;
            }
            else if ((roleType == Role.RoleType.Catalogue))
            {
                supplierLabel.Visible = !value;
                SupplierTextBox.Visible = !value;
                DescriptionTextBox.Visible = value;
                descriptionLabel.Visible = value;
                expiryDateTextBox.Visible = !value;
                ExpiryDateLabel.Visible = !value;
                pricetextBox1.Visible = value;
                pricelbl.Visible = value;



            }

        }
        private void EnableEntries(bool value)
        {
            if ((state == FormStates.Edit) && value)
            {
                idTextBox.Enabled = !value;
                ItemNameTextBox.Enabled = !value;
            }
            else
            {
                idTextBox.Enabled = value;
                ItemNameTextBox.Enabled = value;
            }
            SupplierTextBox.Enabled = value;
            DescriptionTextBox.Enabled = value;
            expiryDateTextBox.Enabled = value;
            
            if (state == FormStates.Delete)
            {
                cancelButton.Visible = !value;
                submitButton.Visible = !value;
            }
            else
            {
                cancelButton.Visible = value;
                submitButton.Visible = value;
            }
        }
        private void ClearAll()
        {
            idTextBox.Text = "";
            ItemNameTextBox.Text = "";
            SupplierTextBox.Text = "";
            DescriptionTextBox.Text = "";
            expiryDateTextBox.Text = "";
            
        }

        private void PopulateTextBoxes(Product prod)
        {
            HeadWaiter headW;
            Waiter waiter;
            Runner runner;
            Catalogue catalogue;
            Product product;
            idTextBox.Text = prod.getItemId();
            SupplierTextBox.Text = prod.ItemName;
            DescriptionTextBox.Text = prod.getSupplier();

            switch (prod.role.getRoleValue)
            {
                case Role.RoleType.Product:
                    prod = (Product)(prod.role);
                    DescriptionTextBox.Text = prod.getSupplier();
                    expiryDateTextBox.Text = Convert.ToString(prod.GetHashCode());
                    break;
                case Role.RoleType.Inventory:
                    waiter = (Waiter)(prod.role);
                    expiryDateTextBox.Text = Convert.ToString(waiter.getRate);
                    
                    break;
                case Role.RoleType.Catalogue:
                    runner = (Runner)(prod.role);
                    expiryDateTextBox.Text = Convert.ToString(runner.getRate);
                    
                    break;
            }
        }

        #endregion

        private void employeeListViews_SelectedIndexChanged(object sender, EventArgs e)
        {
            ShowAll(true, roleValue);
            state = FormStates.View;
            EnableEntries(false);
            if (employeeListViews.SelectedItems.Count > 0)   // if you selected an item 
            {
                employee = prodController.Find(employeeListViews.SelectedItems[0].Text);  //selected prod becoms current prod
                                                                                              //prod = prodController.Find(Convert.ToString(employeeListViews.SelectedItems[0]));  //selected prod becomes current prod
                PopulateTextBoxes(employee);

            }
        }

        private void editButton_Click(object sender, EventArgs e)
        {

        }
    }
}
