﻿using GoodFoodSystem.DatabaseLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodFoodSystem.BusinessLayer
{
    public class Product:Role
    {
        #region Info
        /*Create the derived class Employee from the Person class. 
          An employee has an employee number/ID and a role at the restaurant. 
          Since there are different types of product with different ROLES in a restaurant, 
          we will create a Role class. Three derived classes (headwaiter, waiter and runner) 
          that inherit the role class will be created first 
          (We can say that a waiter IS A specific role an employee might have in the restaurant, etc.).
          The headwaiter has only salary as a data member. The runner and the waiter have the following attributes: 
          tips, rate and noOfShifts. For now do not include the constructor for these classes. 
          Implement the classes, observing OOP principles. Include encapsulation principles.   */
        #endregion

        #region Data Members
        //encapsulation
        private string empId;
        //need to define a role here - Question 3-Make sure the role data member of this class is of class type Role.
        public Role role;


        private string ItemId;
        private string description;
        private string supplier;
        private string expiryDate;
        private string itemName;

        #endregion

        #region Property methods
        public string EmployeeID
        {
            get { return empId; }
            set { empId = value; }
        }

        public string ItemName { get => itemName; set => itemName = value; }
        #endregion

        #region Constructor
        /*
         * Include the constructor of the class.                                                                                                           
            The constructor should have one argument roleValue of type Role. 
            This is because upon the invocation of this class, the role of the employee should be determined.
            Use a switch statement to find the specific role as follows (for more on switch statements):
            If there is no role yet, then:                  role = new Role ();
            If the role is Headwaiter, then:                     role = new HeadWaiter ();

         */

        public Product(Role.RoleType roleValue)
            : this()
        {
            
            switch (roleValue)
            {
                case Role.RoleType.NoRole:
                    role = new Role();
                    break;
                case Role.RoleType.Catalogue:
                    role = new Catalogue();
                    break;
                case Role.RoleType.Waiter:
                    role = new Inventory();
                    break;
                case Role.RoleType.Runner:
                    role = new Runner();
                    break;
            }
        }
        public Product()
        {
            this.ItemId = null;
            this.description = null;
            this.supplier = null;
            this.expiryDate = null;
        }
        #endregion


       

        #region Getters and Setters
        public string getItemId()
        {
            return ItemId;
        }

        public void setProductId(string id)
        {
            ItemId = id;
        }

        public string getDescription()
        {
            return description;
        }

        public void setDescription(string desc)
        {
            description = desc;
        }

        public string getSupplier()
        {
            return this.supplier;
        }

        public void setSupplier(string supp)
        {
            this.supplier = supp;
        }

        public string getExpiryDate()
        {
            return this.expiryDate;
        }

        public void setExpiryDate(string exp)
        {
            this.expiryDate = exp;
        }

        #endregion


    }
}
