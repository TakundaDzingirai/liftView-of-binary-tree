﻿using GoodFoodSystem.BusinessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodFoodSystem
{
    class Pro
    {

        #region Attributes
        private int ItemId;
        private string description;
        private string supplier;
        private string expiryDate;
        #endregion

        #region Constructor
        public Pro()
        {
            this.ItemId = 0;
            this.description = null;
            this.supplier = null;
            this.expiryDate = null;
        }
        #endregion

        #region Getters and Setters
        public int getProductId()
        {
            return ItemId;
        }

        public void setProductId(int id)
        {
            ItemId = id;
        }

        public string getDescription()
        {
            return this.description;
        }

        public void setDescription(string desc)
        {
            this.description = desc;
        }

        public string getSupplier()
        {
            return this.supplier;
        }

        public void setSupplier(string supp)
        {
            this.supplier = supp;
        }

        public string getExpiryDate()
        {
            return this.expiryDate;
        }

        public void setExpiryDate(string exp)
        {
            this.expiryDate = exp;
        }

        public static implicit operator Pro(Product v)
        {
            throw new NotImplementedException();
        }

        #endregion

    }
}
